import Footer from './src/main';

/* istanbul ignore next */
Footer.install = function(Vue) {
  Vue.component(Footer.name, Footer);
};

export default Footer;
